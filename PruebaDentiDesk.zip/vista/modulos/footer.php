
<!-- js files -->
<script src='vista/js/jquery.min.js'></script>
<script src="vista/js/index.js"></script>
<!-- /js files -->
</body>
</html>
