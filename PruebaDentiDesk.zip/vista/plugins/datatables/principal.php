<?php

    $mvc = new MvcControlador();
    $mvc->enlacesPaginasControlador();
    include_once "modulos/footer.php";

?>